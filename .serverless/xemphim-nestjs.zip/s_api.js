
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'tvqqq',
  applicationName: 'xemphim-nestjs',
  appUid: 'BvHYZQfVTHc8pbYLtP',
  orgUid: '63218373-a051-43c8-b683-0769bfbbc9d0',
  deploymentUid: 'a7fcd35a-c31b-4924-bd71-157ff02afe33',
  serviceName: 'xemphim-nestjs',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '6.1.6',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'xemphim-nestjs-dev-api', timeout: 6 };

try {
  const userHandler = require('./dist/serverless.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}